<!DOCTYPE html>
<html>
<head>
	<title>Food Ordering App</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="container">
		<h1>Welcome to our Food Ordering App</h1>
		<p>Order your favorite food from the comfort of your home.</p>
		<a href="menu.php" class="button">See our Menu</a>
	</div>
</body>
</html>
