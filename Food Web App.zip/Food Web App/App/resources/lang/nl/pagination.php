<?php
return [

    'previous' => '« Vorige',
    'next' => 'Volgende »',

];