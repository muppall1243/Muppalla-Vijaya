<?php
return [

    'password' => 'Paswoorden moeten minstens 6 tekens lang zijn en overeen stemmen.',
    'reset' => 'Je paswoord werd opnieuw ingesteld.',
    'sent' => 'We hebben je een paswoord-reset link gemaild!',
    'token' => 'Dit paswoord reset token is niet geldig.',
    'user' => 'We vinden geen gebruiker met dat e-mailadres.',

];