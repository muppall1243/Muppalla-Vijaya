<?php
return [

    'failed' => 'Deze inloggegevens zijn ons onbekend.',
    'throttle' => 'Te veel inlogpogingen. Probeer opnieuw in :seconds seconden.',

];