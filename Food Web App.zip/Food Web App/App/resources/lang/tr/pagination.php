<?php
return [

    'previous' => '« Önce',
    'next' => 'Sonra »',

];