<?php
return [

    'previous' => 'Ankstesnis',
    'next' => 'Sekantis',

];