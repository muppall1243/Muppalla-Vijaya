<?php
return [

    'previous' => '« Мінулая',
    'next' => 'Наступная »',

];