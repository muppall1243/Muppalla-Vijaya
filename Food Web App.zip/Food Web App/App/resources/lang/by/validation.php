<?php
return [

    'accepted' => 'Значэнне :attribute павінна быць прынята.',
    'active_url' => 'Значэнне :attribute не ёсць спасылкай.',
    'after' => 'Значэнне :attribute павінна быць датай пасля :date.',
    'custom' => [
        'attribute-name' => [
            'rule-name' => 'адвольнае паведамленне',
        ],
    ],

];