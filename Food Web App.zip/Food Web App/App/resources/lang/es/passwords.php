<?php
return [

    'reset' => 'Su contraseña ha sido restablecida!',
    'password' => 'Las contraseñas deben tener al menos seis caracteres y coincidir con la confirmación.',
    'sent' => 'Hemos enviado por correo electrónico su enlace de restablecimiento de contraseña!',
    'token' => 'El código de restauración de contraseña es incorrecto.',
    'user' => 'No podemos encontrar un usuario con esa dirección de correo electrónico.',

];