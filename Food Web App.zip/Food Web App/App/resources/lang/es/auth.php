<?php
return [

    'throttle' => 'Muchos intentos para ingresar. Por favor intente de nuevo en :seconds segundos',
    'failed' => 'Estas credenciales no coinciden con nuestros registros.',

];