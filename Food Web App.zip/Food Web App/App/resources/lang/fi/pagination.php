<?php
return [

    'previous' => '« Edellinen',
    'next' => 'Seuraava »',

];