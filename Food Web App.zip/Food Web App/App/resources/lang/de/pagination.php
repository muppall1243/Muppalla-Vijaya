<?php
return [

    'previous' => '« Vorherige',
    'next' => 'Nächste »',

];