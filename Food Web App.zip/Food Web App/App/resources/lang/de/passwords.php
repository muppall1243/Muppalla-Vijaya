<?php
return [

    'password' => 'Passwörter müssen mindestens 6 Zeichen lang und identisch sein.',
    'reset' => 'Ihr Passwort wurde zurückgesetzt!',
    'sent' => 'Wir haben ihnen einen Link gesendet!',
    'token' => 'Das Token ist ungültig.',
    'user' => 'Wir kennen diese E-Mail-Adresse nicht.',

];