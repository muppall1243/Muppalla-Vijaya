<?php
return [

    'failed' => 'Aquestes credencials no corresponen a cap dels nostres registres',
    'throttle' => 'Massa intents per entrar. Prova-ho de nou en :secons segons',

];