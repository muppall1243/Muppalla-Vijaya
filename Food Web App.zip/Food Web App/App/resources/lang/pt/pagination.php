<?php
return [

    'previous' => '« Anterior',
    'next' => 'Próximo »',

];