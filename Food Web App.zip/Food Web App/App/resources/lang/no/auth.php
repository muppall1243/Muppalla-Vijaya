<?php
return [

    'failed' => 'Brukernavn eller passord stemmer ikke med våre data.',
    'throttle' => 'For mange innloggingsforsøk. Prøv igjen om :seconds sekunder.',

];