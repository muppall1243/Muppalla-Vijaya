<?php
return [

    'password' => 'Passordet må være minst seks karakterer og samsvare med bekreftelsen',
    'reset' => 'Ditt passord er nå satt!',
    'sent' => 'Vi har sent deg en link til tilbakestilling av passord!',
    'token' => 'Tilbakestill passord linken er ugyldig',
    'user' => 'Vi kan ikke finne en bruker med den epostadressen',

];