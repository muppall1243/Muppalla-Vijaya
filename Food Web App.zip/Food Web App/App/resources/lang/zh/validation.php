<?php
return [

    'date' => ':attribute並不是正確的日期',
    'date_format' => ':attribute並乎合:format的格式要求',
    'filled' => ':attribute必須填寫',
    'custom' => [
        'attribute-name' => [
            'rule-name' => '自定訊息',
        ],
    ],

];