<?php
return [

    'previous' => '« 上一頁',
    'next' => '下一頁 »',

];