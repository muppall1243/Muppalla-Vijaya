<?php
return [

    'reset' => 'Votre mot de passe a été réinitialisé.',
    'password' => 'Le mot de passe doit comporter au moins 6 caractères et correspondre à la confirmation.',
    'sent' => 'Nous venons de vous envoyez un email avec un lien pour réinitialiser votre mot de passe.',
    'token' => 'Le lien de réinitialisation du mot de passe n\'est pas valide.',
    'user' => 'Nous ne trouvons pas d\'utilisateur correspondant à cette adresse email.',

];