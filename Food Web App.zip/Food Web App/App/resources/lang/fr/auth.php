<?php
return [

    'failed' => 'Ces identifiants ne sont pas reconnus.',
    'throttle' => 'Trop de tentatives de connexion échouées. Veuillez réessayer dans :seconds secondes.',

];