<?php
return [

    'accepted' => 'gfhgf',
    'active_url' => 'hgfhgfhgf',
    'after' => 'hgfhgfh',

];