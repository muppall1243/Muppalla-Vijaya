<?php
return [

    'failed' => 'A megadott adatok nem egyeznek az általunk ismertekkel.',
    'throttle' => 'Túl sok bejelentkezési kísérlet. Legközelebb :seconds másodperc múlva próbálja meg.',

];