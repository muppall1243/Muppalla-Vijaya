<?php
return [

    'previous' => '« Előző',
    'next' => 'Következő »',

];