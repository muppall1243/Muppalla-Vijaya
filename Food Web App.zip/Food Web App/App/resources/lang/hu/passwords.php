<?php
return [

    'password' => 'A jelszónak legalább 6 karakterből kell állnia.',
    'reset' => 'A jelszót töröltük!',
    'sent' => 'Elküldtük a jelszó törléséhez szükséges emailt!',
    'token' => 'A jelszó törlés token érvénytelen.',
    'user' => 'A megadott e-mail címmel nem található felhasználó.',

];