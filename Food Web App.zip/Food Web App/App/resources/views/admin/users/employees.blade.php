@inject('request', 'Illuminate\Http\Request')
@extends('layouts.app')

@section('content')
    <h3 class="page-title">Employees</h3>


    <div class="panel panel-default">
        <div class="panel-heading">
            @lang('quickadmin.qa_list')
        </div>

        <div class="panel-body table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        

                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Salary</th>
                       
                    </tr>
                </thead>
                
                <tbody>
                    @if (count($response) > 0)
                        @foreach ($response as $response)
                            <tr data-entry-id="{{ $response->id }}">
                               

                                <td field-key='first_name'>{{ $response->firstName }}</td>
                                <td field-key='last_name'>{{ $response->lastName }}</td>
                                <td field-key='address'>{{ $response->salary }}</td>
                              
                               
                                
                                
                            </tr>
                        @endforeach
                    @else
                        <tr>
                            <td colspan="11">@lang('quickadmin.qa_no_entries_in_table')</td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
@stop

@section('javascript') 
    <script>
       

    </script>
@endsection