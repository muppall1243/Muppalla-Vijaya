<?php
// Database credentials
$host = "localhost:3310";
$user = "root@";
$password = "";
$database = "food_ordering";

// Create database connection
$conn = mysqli_connect($host, $user, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
