<!DOCTYPE html>
<html>
<head>
	<title>Food Menu</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="container">
		<h1>Our Menu</h1>
		<?php
			// Fetch menu items from the database
			$servername = "localhost:3310";
			$username = "root@";
			$password = "";
			$dbname = "food_ordering";

			// Create connection
			$conn = new mysqli($servername, $username, $password, $dbname);

			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}

			// Fetch menu items
			$sql = "SELECT * FROM menu_items";
			$result = $conn->query($sql);

			// Display menu items
			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					echo "<div class='menu-item'>
							<h2>" . $row["name"] . "</h2>
							<p>" . $row["description"] . "</p>
							<h3>$" . $row["price"] . "</h3>
							<a href='cart.php?action=add&id=" . $row["id"] . "' class='button'>Add to Cart</a>
						</div>";
				}
			} else {
				echo "No menu items available";
			}

			$conn->close();
		?>
	</div>
</body>
</html>
