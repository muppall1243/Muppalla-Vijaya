<!DOCTYPE html>
<html>
<head>
	<title>Cart</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="container">
		<h1>Cart</h1>
		<?php
		
			session_start();
			
			include("db_connect.php");

			// Initialize cart array
			if (!isset($_SESSION["cart"])) {
				$_SESSION["cart"] = array();
			}

			// Handle cart actions
			if (isset($_GET["action"])) {
				$id = $_GET["id"];
				switch ($_GET["action"]) {
					case "add":
						if (!isset($_SESSION["cart"][$id])) {
							$_SESSION["cart"][$id] = 1;
						} else {
							$_SESSION["cart"][$id]++;
						}
						break;
					case "remove":
						if (isset($_SESSION["cart"][$id])) {
							unset($_SESSION["cart"][$id]);
						}
						break;
					case "empty":
						unset($_SESSION["cart"]);
			}}
		// Display cart items
		
		if (count($_SESSION["cart"]) > 0) {
    echo "<table>";
    echo "<tr><th>Name</th><th>Price</th><th>Quantity</th><th>Total</th><th>Action</th></tr>";
    $total = 0;
    foreach ($_SESSION["cart"] as $id => $quantity) {
        // Retrieve menu item from database
        $sql = "SELECT * FROM menu_items WHERE id = '$id'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $name = $row["name"];
            $price = $row["price"];
            $item_total = $price * $quantity;
            $total += $item_total;
            echo "<tr><td>$name</td><td>$price</td><td>$quantity</td><td>$item_total</td><td><a href='cart.php?action=remove&id=$id'>Remove</a></td></tr>";
        }
    }
    echo "<tr><td colspan='3'><b>Total</b></td><td><b>$total</b></td></tr>";
	
//	echo "<td><a href='cart.php?action=empty'>Empty Cart</a></td>"
    
	echo "</table>";
} else {
    echo "Your cart is empty.";
}
			
?>
	<br>
	<a href="menu.php">Back to menu</a>
</div>
</body>
</html>